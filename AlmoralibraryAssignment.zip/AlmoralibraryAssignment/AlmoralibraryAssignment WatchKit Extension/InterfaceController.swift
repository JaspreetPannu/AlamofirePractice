//
//  InterfaceController.swift
//  AlmoralibraryAssignment WatchKit Extension
//
//  Created by Jaspreet Pannu on 2020-08-23.
//  Copyright © 2020 Jaspreet Pannu. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity

class InterfaceController: WKInterfaceController,WCSessionDelegate {
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    

    @IBOutlet weak var search: WKInterfaceTextField!
    
    @IBOutlet weak var sunRise: WKInterfaceLabel!
    
    @IBOutlet weak var sunSet: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        print("Welcome")
               if WCSession.isSupported() {
               let session = WCSession.default
               session.delegate = self
               session.activate()
        }
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        // Play a "click" sound when you get the message
        WKInterfaceDevice().play(.click)
        
        DispatchQueue.main.async{
            if let sunrise = message["SunRise"] as? String
            {
            self.sunRise.setText(sunrise)
            }
            if let sunset = message["SunSet"] as? String
            {
            self.sunSet.setText(sunset)
            }
            if let city = message["city"] as? String
                       {
                       self.search.setText(city)
                       }
                        
                       // update the message with a label
    }
    }
    

}
